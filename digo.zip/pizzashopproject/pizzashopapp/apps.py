from django.apps import AppConfig


class PizzashopappConfig(AppConfig):
    name = 'pizzashopapp'
